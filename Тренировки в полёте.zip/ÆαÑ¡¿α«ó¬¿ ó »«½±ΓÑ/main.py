from flask import Flask, render_template
# import os
app = Flask(__name__)
# <!--    {% if  %}-->
# <!--    <static src='static/simulator.png'>-->
# <!--    {% else %}-->
# <!--    <static src='static/trening.png'>-->
# <!--    {% endif %}-->
@app.route("/training/<prof>")
def mars(prof):
    # os.path.isfile("")
    return render_template("base.html", prof=prof)
    # return "fdf"
if __name__ == "__main__":
    app.run(port=8080, host="127.0.0.1")
